/*
 * Copyright (c) 2010-2026 OTClient <https://github.com/edubart/otclient>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#pragma once

#ifndef USE_PRECOMPILED_HEADERS
#include <string>
#include <unordered_map>
#include <vector>
#endif

#include "declarations.h"

namespace css {
    struct PseudoInfo
    {
        std::string name;
        bool negated{ false };
    };

    struct SelectorMeta
    {
        std::vector<PseudoInfo> pseudos;
    };

    struct Declaration
    {
        std::string property;
        std::string value;
        bool important{ false };
    };

    struct Rule
    {
        std::vector<std::string> selectors;
        std::vector<SelectorMeta> selectorMeta;
        std::vector<Declaration> decls;
        int order{ 0 };
    };

    struct StyleSheet
    {
        std::vector<Rule> rules;
    };

    using StyleMap = std::unordered_map<std::string, std::string>;

    struct CascadeOptions
    {
        bool parse_inline_style{ true };
        bool media_always_true{ true };
    };

    StyleSheet parse(const std::string& cssText);
    std::vector<Declaration> parseDeclarationList(const std::string& block);

    void applyStyleSheet(const HtmlNodePtr& root,
                         const StyleSheet& sheet,
                         std::unordered_map<const HtmlNode*, StyleMap>& out,
                         const CascadeOptions& opts = {});
}

