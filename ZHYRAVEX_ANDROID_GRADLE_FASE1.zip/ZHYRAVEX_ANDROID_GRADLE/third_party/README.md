# Dependencias nativas pendientes

El proyecto Android original enlazaba estas bibliotecas estáticas desde `C:\android\lib` y `C:\android\lib64`:

- Boost System
- Vorbis / Vorbisfile
- OpenSSL (ssl + crypto)
- libpng
- PhysicsFS
- OpenAL
- Ogg
- LuaJIT
- libzip

Para compilar, coloca los headers en `third_party/include/` y las bibliotecas por ABI en:

- `third_party/prebuilt/arm64-v8a/lib*.a`
- `third_party/prebuilt/armeabi-v7a/lib*.a`

El CMake falla de forma explícita indicando la primera biblioteca que falta. La siguiente fase de la migración es automatizar también la construcción de estas dependencias con NDK.
