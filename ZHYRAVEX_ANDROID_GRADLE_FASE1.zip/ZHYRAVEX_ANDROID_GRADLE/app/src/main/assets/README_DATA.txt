ZHYRAVEX necesita data.zip en esta carpeta para ejecutar los recursos del juego.
El proyecto Android original también esperaba exactamente: app/src/main/assets/data.zip
No se incluye en este paquete de migración para mantener pequeñas y rápidas las pruebas de compilación del motor.
